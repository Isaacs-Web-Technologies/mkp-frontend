"use strict";
exports.id = 846;
exports.ids = [846];
exports.modules = {

/***/ 1794:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7184);

const AxiosInstance = axios__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .Z.create({
    baseURL: "/"
});
AxiosInstance.interceptors.request.use((config)=>{
    const token = localStorage.getItem("token");
    if (token) {
        config.headers["Authorization"] = `${token}`;
    }
    return config;
}, (error)=>{
    return Promise.reject(error);
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (AxiosInstance);


/***/ }),

/***/ 8792:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/GoogleIcon.69654826.png","height":30,"width":30,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAZlBMVEVMaXHhNCgyoUX9wwAnlEzVJSniLCwvnUDlNSlZfbxbf8T0uwRYfLx/i4tWfL3jNijkOCq/thUrpEj3mAzqMiwuoTRYbs0unzxSi6lac81dg8g6olrgNyobm0g3sEpatT75PS7/VCZxSTP3AAAAHnRSTlMAo/rfGRg+pvum/cvAC8y3X43bi9sxLrr3H9v2sErEaxnxAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAQUlEQVR4nB3GxxGAIAAAwQPJIphz7L9JZ9jXghbOZQN6fE/hWhg+Q1HVND5FXxJT2OmeC7bgUf1t7bHOoKyUy8QPWTkCszj7HWgAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 8458:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/apple.62d71682.png","height":30,"width":30,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAAJFBMVEUAAABMaXEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAB1rdTyAAAADHRSTlP+APkShSSyPb/T6WODAR2SAAAACXBIWXMAAAsTAAALEwEAmpwYAAAANUlEQVR4nB3IyQ3AMAzEwKVu2/33Gyh8DSiACBC4Vy/Czlih1PZQ/2iUJpnGRe25LvKe0eMDF4oAvLr+FccAAAAASUVORK5CYII=","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 6613:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/microsoft.9e4fcd6d.png","height":30,"width":30,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAICAMAAADz0U65AAAASFBMVEX+vQT6Txb0TRoArO7xUBv6vAkAre9+zygArvSAzCj2ThV6zin/ugEArvsAtf/5ShT/yAkAufyH1yr8VBv7vAn/VRuO4i3/WhwQt7soAAAAEHRSTlPEw8H6/fz+xMT9zZSUlMOUTfOQYwAAAAlwSFlzAAALEwAACxMBAJqcGAAAAD5JREFUeJw9xjcSgDAMAMEzDpKJkkz4/0+ZoWCrpZQxSfTOn2s8Se4IUpqPRURQ1W0FcPcdMyNnV6xWWvtyvlohAnbSOkKLAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":8});

/***/ }),

/***/ 4778:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/mkpSignupImg.fc3f1814.png","height":476,"width":524,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAHCAMAAAACh/xsAAAAeFBMVEVMaXHJ6v+qbjPW8f3FzOusgTuVZzm23fyxppe4jlTd3uW3s6/J1N6jppasfUaqvbZtq3hot3xnwG7a2dxfn3VndxvJg0++j0ewtcvMw8jHUxbwm17X6/rb6POUelDpu5ZMgTQOnCuhWCyyZUXxz7OEh03UqYD1q4JhSG51AAAAHnRSTlMAKv5yJf39FvD+5rm12vltoWQl2dz5+f2t7Pn9uZUvJjjJAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAQklEQVR4nAXBhQHAIBAEsEMfqLtDDbr/hk0AtrtllgC5b5ti30KElfPhanAk/dzqrCHeUfvSV6AuKGsLAlhuTCbxA3k6A4iaxEHjAAAAAElFTkSuQmCC","blurWidth":8,"blurHeight":7});

/***/ })

};
;