(() => {
var exports = {};
exports.id = 931;
exports.ids = [931];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 5868:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/app-render");

/***/ }),

/***/ 1844:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param");

/***/ }),

/***/ 6624:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes");

/***/ }),

/***/ 5281:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/route-modules/route-module");

/***/ }),

/***/ 7085:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context");

/***/ }),

/***/ 1830:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/get-img-props");

/***/ }),

/***/ 199:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hash");

/***/ }),

/***/ 6864:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head");

/***/ }),

/***/ 9569:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context");

/***/ }),

/***/ 2210:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config");

/***/ }),

/***/ 5359:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context");

/***/ }),

/***/ 7160:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context");

/***/ }),

/***/ 893:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix");

/***/ }),

/***/ 2336:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url");

/***/ }),

/***/ 7887:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll");

/***/ }),

/***/ 8735:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot");

/***/ }),

/***/ 120:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url");

/***/ }),

/***/ 8231:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path");

/***/ }),

/***/ 4614:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix");

/***/ }),

/***/ 3750:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash");

/***/ }),

/***/ 982:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href");

/***/ }),

/***/ 9618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html");

/***/ }),

/***/ 8423:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils");

/***/ }),

/***/ 8658:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once");

/***/ }),

/***/ 9528:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GlobalError: () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   __next_app__: () => (/* binding */ __next_app__),
/* harmony export */   originalPathname: () => (/* binding */ originalPathname),
/* harmony export */   pages: () => (/* binding */ pages),
/* harmony export */   routeModule: () => (/* binding */ routeModule),
/* harmony export */   tree: () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(7262);
/* harmony import */ var next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(9513);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1823);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2502);
/* harmony import */ var next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__);
/* harmony reexport (unknown) */ var __WEBPACK_REEXPORT_OBJECT__ = {};
/* harmony reexport (unknown) */ for(const __WEBPACK_IMPORT_KEY__ in next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__) if(["default","tree","pages","GlobalError","originalPathname","__next_app__","routeModule"].indexOf(__WEBPACK_IMPORT_KEY__) < 0) __WEBPACK_REEXPORT_OBJECT__[__WEBPACK_IMPORT_KEY__] = () => next_dist_server_app_render_entry_base__WEBPACK_IMPORTED_MODULE_3__[__WEBPACK_IMPORT_KEY__]
/* harmony reexport (unknown) */ __webpack_require__.d(__webpack_exports__, __WEBPACK_REEXPORT_OBJECT__);
// @ts-ignore this need to be imported from next/dist to be external


const AppPageRouteModule = next_dist_server_future_route_modules_app_page_module__WEBPACK_IMPORTED_MODULE_0__.AppPageRouteModule;
// We inject the tree and pages here so that we can use them in the route
// module.
const tree = {
        children: [
        '',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 3158)), "C:\\Users\\Ibinabo\\Documents\\GitHub\\mkp-frontend\\mkp\\app\\page.js"],
          
        }]
      },
        {
        'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5764)), "C:\\Users\\Ibinabo\\Documents\\GitHub\\mkp-frontend\\mkp\\app\\layout.js"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 5493, 23)), "next/dist/client/components/not-found-error"],
        
      }
      ]
      }.children;
const pages = ["C:\\Users\\Ibinabo\\Documents\\GitHub\\mkp-frontend\\mkp\\app\\page.js"];

// @ts-expect-error - replaced by webpack/turbopack loader

const __next_app_require__ = __webpack_require__
const __next_app_load_chunk__ = () => Promise.resolve()
const originalPathname = "/page";
const __next_app__ = {
    require: __next_app_require__,
    loadChunk: __next_app_load_chunk__
};

// Create and export the route module that will be consumed.
const routeModule = new AppPageRouteModule({
    definition: {
        kind: next_dist_server_future_route_kind__WEBPACK_IMPORTED_MODULE_1__/* .RouteKind */ .x.APP_PAGE,
        page: "/page",
        pathname: "/",
        // The following aren't used in production.
        bundlePath: "",
        filename: "",
        appPaths: []
    },
    userland: {
        loaderTree: tree
    }
});

//# sourceMappingURL=app-page.js.map

/***/ }),

/***/ 8287:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 831, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2987, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6926, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 4282, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6505, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 1232, 23))

/***/ }),

/***/ 9745:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3380, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 4666));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 6939));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8153));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 2270));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8932));
Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 8144))

/***/ }),

/***/ 8932:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  ExploreNigerianRecipies: () => (/* binding */ ExploreNigerianRecipies)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./data/exploreNigerianRecipies.json
const exploreNigerianRecipies_namespaceObject = JSON.parse('[{"id":1,"image":"/images/friedrice.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":2,"image":"/images/eba.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":3,"image":"/images/jollofrice.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":4,"image":"/images/friedchicken.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"}]');
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/landingPgComponents/ExploreNigerianRecipies.jsx
/* __next_internal_client_entry_do_not_use__ ExploreNigerianRecipies auto */ 



const ExploreNigerianRecipies = ({})=>{
    const [showAll, setShowAll] = (0,react_.useState)(false);
    const toggleCards = ()=>{
        setShowAll(!showAll);
    };
    const cardContainerStyle = {
        display: "flex",
        flexWrap: "nowrap",
        overflowX: showAll ? "auto" : "hidden"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " font-poppins",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-2xl font-semibold",
                        children: "Explore Nigerian Recipes"
                    }),
                    exploreNigerianRecipies_namespaceObject.length > 3 && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: toggleCards,
                        className: "bg-transparent border rounded p-2 text-primary hover:bg-primary hover:text-white",
                        children: showAll ? "Collapse" : "Expand"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: cardContainerStyle,
                className: "overflow-x-hidden",
                children: exploreNigerianRecipies_namespaceObject.map((recipe)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2 lg:w-1/3 xl:w-1/4 p-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-white rounded-lg shadow-md overflow-hidden",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: recipe.image,
                                    alt: recipe.title,
                                    width: 500,
                                    height: 500,
                                    className: "w-full h-40 object-cover"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "p-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-xl font-semibold mb-2",
                                            children: recipe.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: recipe.link,
                                            className: "text-primary",
                                            children: "View Recipe"
                                        })
                                    ]
                                })
                            ]
                        })
                    }, recipe.id))
            })
        ]
    });
};


/***/ }),

/***/ 2270:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  FreshFromCommunity: () => (/* binding */ FreshFromCommunity)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./data/freshFrmCommunity.json
const freshFrmCommunity_namespaceObject = JSON.parse('[{"id":1,"image":"/images/potato.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":2,"image":"/images/potatoandsalad.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":3,"image":"/images/breadandpancake.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":4,"image":"/images/eggandsalad.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"}]');
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/landingPgComponents/frshFrmCommunity.jsx
/* __next_internal_client_entry_do_not_use__ FreshFromCommunity auto */ 



const FreshFromCommunity = ({})=>{
    const [showAll, setShowAll] = (0,react_.useState)(false);
    const toggleCards = ()=>{
        setShowAll(!showAll);
    };
    const cardContainerStyle = {
        display: "flex",
        flexWrap: "nowrap",
        overflowX: showAll ? "auto" : "hidden"
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " font-poppins",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-2xl font-semibold",
                        children: "Fresh from Community"
                    }),
                    freshFrmCommunity_namespaceObject.length > 3 && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: toggleCards,
                        className: "bg-transparent border rounded p-2 text-primary hover:bg-primary hover:text-white",
                        children: showAll ? "Collapse" : "Expand"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: cardContainerStyle,
                className: "overflow-x-hidden",
                children: freshFrmCommunity_namespaceObject.map((recipe)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2 lg:w-1/3 xl:w-1/4 p-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-white rounded-lg shadow-md overflow-hidden",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: recipe.image,
                                    alt: recipe.title,
                                    width: 500,
                                    height: 500,
                                    className: "w-full h-40 object-cover"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "p-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-xl font-semibold mb-2",
                                            children: recipe.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: recipe.link,
                                            className: "text-primary",
                                            children: "View Recipe"
                                        })
                                    ]
                                })
                            ]
                        })
                    }, recipe.id))
            })
        ]
    });
};


/***/ }),

/***/ 8153:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  LatestRecipes: () => (/* binding */ LatestRecipes)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
;// CONCATENATED MODULE: ./data/latestRecipes.json
const latestRecipes_namespaceObject = JSON.parse('[{"id":1,"image":"/images/potato.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":2,"image":"/images/potatoandsalad.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":3,"image":"/images/breadandpancake.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"},{"id":4,"image":"/images/eggandsalad.jpeg","title":"PASTA TOMATO SAUCE WITH CHICKEN","link":"/"}]');
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./components/landingPgComponents/latestRecipies.jsx
/* __next_internal_client_entry_do_not_use__ LatestRecipes auto */ 



const LatestRecipes = ({})=>{
    const [showAll, setShowAll] = (0,react_.useState)(false);
    const toggleCards = ()=>{
        setShowAll(!showAll);
    };
    const cardContainerStyle = {
        display: "flex",
        flexWrap: "nowrap",
        overflowX: showAll ? "auto" : "hidden"
    };
    console.log(latestRecipes_namespaceObject);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: " font-poppins",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "flex items-center justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h2", {
                        className: "text-2xl font-semibold",
                        children: "Latest Recipes"
                    }),
                    latestRecipes_namespaceObject.length > 3 && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        onClick: toggleCards,
                        className: "bg-transparent border rounded p-2 text-primary hover:bg-primary hover:text-white",
                        children: showAll ? "Collapse" : "Expand"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                style: cardContainerStyle,
                className: "overflow-x-hidden",
                children: latestRecipes_namespaceObject.map((recipe)=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/2 lg:w-1/3 xl:w-1/4 p-4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: "bg-white rounded-lg shadow-md overflow-hidden",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: recipe.image,
                                    alt: recipe.title,
                                    width: 500,
                                    height: 500,
                                    className: "w-full h-40 object-cover"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "p-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                            className: "text-xl font-semibold mb-2",
                                            children: recipe.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                            href: recipe.link,
                                            className: "text-primary",
                                            children: "View Recipe"
                                        })
                                    ]
                                })
                            ]
                        })
                    }, recipe.id))
            })
        ]
    });
};


/***/ }),

/***/ 6939:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SearchBar: () => (/* binding */ SearchBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(8038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_icons_fi__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(7593);
/* __next_internal_client_entry_do_not_use__ SearchBar auto */ 


const SearchBar = ()=>{
    const [isFavorite, setIsFavorite] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [searchText, setSearchText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("");
    const handleFavoriteClick = ()=>{
        setIsFavorite(!isFavorite);
        // Here, you can implement your logic to save or remove the search text.
        if (!isFavorite) {
            // Save the search text
            console.log("Saved search:", searchText);
        } else {
            // Remove the search text
            console.log("Removed search:", searchText);
        }
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "relative w-full lg:max-w-[75%] max-w-md mx-auto pt-12 pb-10 font-poppins",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "flex items-center border border-gray-800 shadow-md rounded-lg",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: "text",
                    placeholder: "How to cook bolognese...",
                    className: "w-full py-2 px-4 pr-16 rounded-lg border-none ",
                    value: searchText,
                    onChange: (e)=>setSearchText(e.target.value)
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: `${isFavorite ? "text-red-500" : "text-gray-500"} border-none bg-transparent p-2 rounded-lg hover:bg-opacity-80`,
                    onClick: handleFavoriteClick,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__/* .FiSend */ .LbG, {
                        size: 24
                    })
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                    className: "bg-white text-red-500 border-none ml-2 p-2 rounded-full shadow-md hover:bg-opacity-80",
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_icons_fi__WEBPACK_IMPORTED_MODULE_2__/* .FiHeart */ .$aX, {
                        size: 24
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 8144:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  Navbar: () => (/* binding */ Navbar)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(8038);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1440);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/navbar/NavLinks.jsx


const NavLinks = ({ showLinks })=>{
    const linkStyles = "text-black hover:text-red ";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
        className: ` top-0 lg:flex list-none justify-between lg:items-center gap-10 ${showLinks ? "block " : "hidden md:hidden list-none"}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: linkStyles,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: "Recipes"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: linkStyles,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: "Popular"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: linkStyles,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: "Cuisine"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: linkStyles,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: "Kitchen Tips"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                className: linkStyles,
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "/",
                    children: "About Us"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "./signIn",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "ml-5 flex outline_btn",
                        children: "Login"
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("li", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((link_default()), {
                    href: "./signUp",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "ml-2 flex   black_btn",
                        children: "Sign up"
                    })
                })
            })
        ]
    });
};

// EXTERNAL MODULE: ../node_modules/react-icons/fa/index.esm.js
var index_esm = __webpack_require__(2449);
;// CONCATENATED MODULE: ./components/navbar/hamburgerMenu.jsx


const HamburgerMenu = ({ isActive, onClick })=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("button", {
        className: "md:hidden   text-gray-700 border-none focus:outline-none",
        onClick: onClick,
        children: isActive ? /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaTimes */.aHS, {
            size: 30,
            color: "gray"
        }) : /*#__PURE__*/ jsx_runtime_.jsx(index_esm/* FaBars */.Fm7, {
            size: 30,
            color: "gray"
        })
    });
};

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(2451);
;// CONCATENATED MODULE: ./public/svgs/mkpLogo.jsx

const MKP = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
        width: "137",
        height: "18",
        viewBox: "0 0 137 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
            d: "M11.112 4.008C12.2 4.008 13.0747 4.344 13.736 5.016C14.408 5.67733 14.744 6.60533 14.744 7.8V13H12.504V8.104C12.504 7.41067 12.328 6.88267 11.976 6.52C11.624 6.14667 11.144 5.96 10.536 5.96C9.928 5.96 9.44267 6.14667 9.08 6.52C8.728 6.88267 8.552 7.41067 8.552 8.104V13H6.312V8.104C6.312 7.41067 6.136 6.88267 5.784 6.52C5.432 6.14667 4.952 5.96 4.344 5.96C3.72533 5.96 3.23467 6.14667 2.872 6.52C2.52 6.88267 2.344 7.41067 2.344 8.104V13H0.104V4.136H2.344V5.208C2.632 4.83467 3 4.54133 3.448 4.328C3.90667 4.11467 4.408 4.008 4.952 4.008C5.64533 4.008 6.264 4.15733 6.808 4.456C7.352 4.744 7.77333 5.16 8.072 5.704C8.36 5.192 8.776 4.78133 9.32 4.472C9.87467 4.16267 10.472 4.008 11.112 4.008ZM25.3496 4.136L19.8616 17.192H17.4776L19.3976 12.776L15.8456 4.136H18.3576L20.6456 10.328L22.9656 4.136H25.3496ZM31.8051 13L28.7971 9.224V13H26.5571V1.16H28.7971V7.896L31.7731 4.136H34.6851L30.7811 8.584L34.7171 13H31.8051ZM37.0369 3.08C36.6422 3.08 36.3115 2.95733 36.0449 2.712C35.7889 2.456 35.6609 2.14133 35.6609 1.768C35.6609 1.39467 35.7889 1.08533 36.0449 0.839999C36.3115 0.583999 36.6422 0.455999 37.0369 0.455999C37.4315 0.455999 37.7569 0.583999 38.0129 0.839999C38.2795 1.08533 38.4129 1.39467 38.4129 1.768C38.4129 2.14133 38.2795 2.456 38.0129 2.712C37.7569 2.95733 37.4315 3.08 37.0369 3.08ZM38.1409 4.136V13H35.9009V4.136H38.1409ZM42.962 5.976V10.264C42.962 10.5627 43.0313 10.7813 43.17 10.92C43.3193 11.048 43.5647 11.112 43.906 11.112H44.946V13H43.538C41.65 13 40.706 12.0827 40.706 10.248V5.976H39.65V4.136H40.706V1.944H42.962V4.136H44.946V5.976H42.962ZM45.9811 8.568C45.9811 7.65067 46.1678 6.85067 46.5411 6.168C46.9145 5.47467 47.4318 4.94133 48.0931 4.568C48.7545 4.184 49.5118 3.992 50.3651 3.992C51.4638 3.992 52.3705 4.26933 53.0851 4.824C53.8105 5.368 54.2958 6.136 54.5411 7.128H52.1251C51.9971 6.744 51.7785 6.44533 51.4691 6.232C51.1705 6.008 50.7971 5.896 50.3491 5.896C49.7091 5.896 49.2025 6.13067 48.8291 6.6C48.4558 7.05867 48.2691 7.71467 48.2691 8.568C48.2691 9.41067 48.4558 10.0667 48.8291 10.536C49.2025 10.9947 49.7091 11.224 50.3491 11.224C51.2558 11.224 51.8478 10.8187 52.1251 10.008H54.5411C54.2958 10.968 53.8105 11.7307 53.0851 12.296C52.3598 12.8613 51.4531 13.144 50.3651 13.144C49.5118 13.144 48.7545 12.9573 48.0931 12.584C47.4318 12.2 46.9145 11.6667 46.5411 10.984C46.1678 10.2907 45.9811 9.48533 45.9811 8.568ZM61.1741 4.008C61.8461 4.008 62.4435 4.15733 62.9661 4.456C63.4888 4.744 63.8941 5.176 64.1821 5.752C64.4808 6.31733 64.6301 7 64.6301 7.8V13H62.3901V8.104C62.3901 7.4 62.2141 6.86133 61.8621 6.488C61.5101 6.104 61.0301 5.912 60.4221 5.912C59.8035 5.912 59.3128 6.104 58.9501 6.488C58.5981 6.86133 58.4221 7.4 58.4221 8.104V13H56.1821V1.16H58.4221V5.24C58.7101 4.856 59.0941 4.55733 59.5741 4.344C60.0541 4.12 60.5875 4.008 61.1741 4.008ZM75.0003 8.376C75.0003 8.696 74.9789 8.984 74.9363 9.24H68.4563C68.5096 9.88 68.7336 10.3813 69.1283 10.744C69.5229 11.1067 70.0083 11.288 70.5843 11.288C71.4163 11.288 72.0083 10.9307 72.3603 10.216H74.7763C74.5203 11.0693 74.0296 11.7733 73.3043 12.328C72.5789 12.872 71.6883 13.144 70.6323 13.144C69.7789 13.144 69.0109 12.9573 68.3283 12.584C67.6563 12.2 67.1283 11.6613 66.7443 10.968C66.3709 10.2747 66.1842 9.47467 66.1842 8.568C66.1842 7.65067 66.3709 6.84533 66.7443 6.152C67.1176 5.45867 67.6403 4.92533 68.3123 4.552C68.9843 4.17867 69.7576 3.992 70.6323 3.992C71.4749 3.992 72.2269 4.17333 72.8883 4.536C73.5603 4.89867 74.0776 5.416 74.4403 6.088C74.8136 6.74933 75.0003 7.512 75.0003 8.376ZM72.6803 7.736C72.6696 7.16 72.4616 6.70133 72.0563 6.36C71.6509 6.008 71.1549 5.832 70.5683 5.832C70.0136 5.832 69.5443 6.00267 69.1603 6.344C68.7869 6.67467 68.5576 7.13867 68.4723 7.736H72.6803ZM81.5473 4.008C82.6033 4.008 83.4566 4.344 84.1073 5.016C84.7579 5.67733 85.0833 6.60533 85.0833 7.8V13H82.8433V8.104C82.8433 7.4 82.6673 6.86133 82.3153 6.488C81.9633 6.104 81.4833 5.912 80.8753 5.912C80.2566 5.912 79.7659 6.104 79.4033 6.488C79.0513 6.86133 78.8753 7.4 78.8753 8.104V13H76.6353V4.136H78.8753V5.24C79.1739 4.856 79.5526 4.55733 80.0113 4.344C80.4806 4.12 80.9926 4.008 81.5473 4.008ZM89.4534 5.416C89.7414 5.01067 90.136 4.67467 90.6374 4.408C91.1494 4.13067 91.7307 3.992 92.3814 3.992C93.1387 3.992 93.8214 4.17867 94.4294 4.552C95.048 4.92533 95.5334 5.45867 95.8854 6.152C96.248 6.83467 96.4294 7.62933 96.4294 8.536C96.4294 9.44267 96.248 10.248 95.8854 10.952C95.5334 11.6453 95.048 12.184 94.4294 12.568C93.8214 12.952 93.1387 13.144 92.3814 13.144C91.7307 13.144 91.1547 13.0107 90.6534 12.744C90.1627 12.4773 89.7627 12.1413 89.4534 11.736V17.224H87.2134V4.136H89.4534V5.416ZM94.1414 8.536C94.1414 8.00267 94.0294 7.544 93.8054 7.16C93.592 6.76533 93.304 6.46667 92.9414 6.264C92.5894 6.06133 92.2054 5.96 91.7894 5.96C91.384 5.96 91 6.06667 90.6374 6.28C90.2854 6.48267 89.9974 6.78133 89.7734 7.176C89.56 7.57067 89.4534 8.03467 89.4534 8.568C89.4534 9.10133 89.56 9.56533 89.7734 9.96C89.9974 10.3547 90.2854 10.6587 90.6374 10.872C91 11.0747 91.384 11.176 91.7894 11.176C92.2054 11.176 92.5894 11.0693 92.9414 10.856C93.304 10.6427 93.592 10.3387 93.8054 9.944C94.0294 9.54933 94.1414 9.08 94.1414 8.536ZM101.993 13.144C101.14 13.144 100.372 12.9573 99.6891 12.584C99.0065 12.2 98.4678 11.6613 98.0731 10.968C97.6891 10.2747 97.4971 9.47467 97.4971 8.568C97.4971 7.66133 97.6945 6.86133 98.0891 6.168C98.4945 5.47467 99.0438 4.94133 99.7371 4.568C100.43 4.184 101.204 3.992 102.057 3.992C102.91 3.992 103.684 4.184 104.377 4.568C105.07 4.94133 105.614 5.47467 106.009 6.168C106.414 6.86133 106.617 7.66133 106.617 8.568C106.617 9.47467 106.409 10.2747 105.993 10.968C105.588 11.6613 105.033 12.2 104.329 12.584C103.636 12.9573 102.857 13.144 101.993 13.144ZM101.993 11.192C102.398 11.192 102.777 11.096 103.129 10.904C103.492 10.7013 103.78 10.4027 103.993 10.008C104.206 9.61333 104.313 9.13333 104.313 8.568C104.313 7.72533 104.089 7.08 103.641 6.632C103.204 6.17333 102.665 5.944 102.025 5.944C101.385 5.944 100.846 6.17333 100.409 6.632C99.9825 7.08 99.7691 7.72533 99.7691 8.568C99.7691 9.41067 99.9771 10.0613 100.393 10.52C100.82 10.968 101.353 11.192 101.993 11.192ZM120.548 4.136L117.956 13H115.54L113.924 6.808L112.308 13H109.876L107.268 4.136H109.54L111.108 10.888L112.804 4.136H115.172L116.836 10.872L118.404 4.136H120.548ZM130 8.376C130 8.696 129.979 8.984 129.936 9.24H123.456C123.51 9.88 123.734 10.3813 124.128 10.744C124.523 11.1067 125.008 11.288 125.584 11.288C126.416 11.288 127.008 10.9307 127.36 10.216H129.776C129.52 11.0693 129.03 11.7733 128.304 12.328C127.579 12.872 126.688 13.144 125.632 13.144C124.779 13.144 124.011 12.9573 123.328 12.584C122.656 12.2 122.128 11.6613 121.744 10.968C121.371 10.2747 121.184 9.47467 121.184 8.568C121.184 7.65067 121.371 6.84533 121.744 6.152C122.118 5.45867 122.64 4.92533 123.312 4.552C123.984 4.17867 124.758 3.992 125.632 3.992C126.475 3.992 127.227 4.17333 127.888 4.536C128.56 4.89867 129.078 5.416 129.44 6.088C129.814 6.74933 130 7.512 130 8.376ZM127.68 7.736C127.67 7.16 127.462 6.70133 127.056 6.36C126.651 6.008 126.155 5.832 125.568 5.832C125.014 5.832 124.544 6.00267 124.16 6.344C123.787 6.67467 123.558 7.13867 123.472 7.736H127.68ZM133.875 5.512C134.163 5.04267 134.537 4.67467 134.995 4.408C135.465 4.14133 135.998 4.008 136.595 4.008V6.36H136.003C135.299 6.36 134.766 6.52533 134.403 6.856C134.051 7.18667 133.875 7.76267 133.875 8.584V13H131.635V4.136H133.875V5.512Z",
            fill: "#39161A"
        })
    });
};
/* harmony default export */ const mkpLogo = (MKP);

;// CONCATENATED MODULE: ./components/navbar/NavBar.jsx
/* __next_internal_client_entry_do_not_use__ Navbar auto */ 






const Navbar = ()=>{
    const [showLinks, setShowLinks] = (0,react_.useState)(false);
    const [isHamburgerActive, setIsHamburgerActive] = (0,react_.useState)(false);
    const handleHamburgerClick = ()=>{
        setIsHamburgerActive(!isHamburgerActive);
        setShowLinks(!showLinks);
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("nav", {
        className: "NavBar w-full h-full  bg-white",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "hidden md:inline lg:flex flex-row",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(mkpLogo, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(NavLinks, {
                        showLinks: true
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "md:hidden",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(HamburgerMenu, {
                        isActive: isHamburgerActive,
                        onClick: handleHamburgerClick
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: `  absolute top-16 right-4  bg-white p-4 shadow-md ${isHamburgerActive ? "block" : "hidden"}`,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(NavLinks, {
                            showLinks: isHamburgerActive
                        })
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 3158:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(6786);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(4178);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
;// CONCATENATED MODULE: ./public/images/heroImg.png
/* harmony default export */ const heroImg = ({"src":"/_next/static/media/heroImg.5488a0fa.png","height":778,"width":1440,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAUVBMVEVyQRhVWDRhUDYqVAd3Sjh/cmBqXi5+XjdRHg1UbkqEhouvsLRWQB+YlpnDrZ6WkIxcPS7HhCGxmnllKSSTYUeSRg6NhIGtspYyEQeIendcQxk+woEjAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAK0lEQVR4nAXBhQEAIAwDsKLD3f8/lASMPyCQhrBNHjMU7K6zm+uwMhUZffoXjAF8fxCZhgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});
;// CONCATENATED MODULE: ./components/landingPgComponents/hero.jsx



const Hero = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: "hero font-poppins",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("h2", {
                        className: "",
                        children: [
                            "Discover new and exciting meal",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            " with CookGPT faster than",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "ever"
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                        className: "text-white text-l mb-4",
                        children: [
                            "Classic and mouth-watering meals and side dishes",
                            /*#__PURE__*/ jsx_runtime_.jsx("br", {}),
                            "for all seasons."
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                        className: "bg-primary text-white px-6 py-4 rounded-lg border-none text-lg",
                        children: "Search for meal"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                src: heroImg,
                alt: "MKP Hero Image",
                className: "w-screen h-screen object-cover",
                priority: true
            })
        ]
    });
};
/* harmony default export */ const hero = (Hero);

// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(1363);
;// CONCATENATED MODULE: ./components/navbar/NavBar.jsx

const proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\Ibinabo\Documents\GitHub\mkp-frontend\mkp\components\navbar\NavBar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
const __default__ = proxy.default;

const e0 = proxy["Navbar"];

;// CONCATENATED MODULE: ./components/landingPgComponents/searchBar.jsx

const searchBar_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\Ibinabo\Documents\GitHub\mkp-frontend\mkp\components\landingPgComponents\searchBar.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: searchBar_esModule, $$typeof: searchBar_$$typeof } = searchBar_proxy;
const searchBar_default_ = searchBar_proxy.default;

const searchBar_e0 = searchBar_proxy["SearchBar"];

;// CONCATENATED MODULE: ./components/landingPgComponents/latestRecipies.jsx

const latestRecipies_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\Ibinabo\Documents\GitHub\mkp-frontend\mkp\components\landingPgComponents\latestRecipies.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: latestRecipies_esModule, $$typeof: latestRecipies_$$typeof } = latestRecipies_proxy;
const latestRecipies_default_ = latestRecipies_proxy.default;

const latestRecipies_e0 = latestRecipies_proxy["LatestRecipes"];

;// CONCATENATED MODULE: ./components/landingPgComponents/frshFrmCommunity.jsx

const frshFrmCommunity_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\Ibinabo\Documents\GitHub\mkp-frontend\mkp\components\landingPgComponents\frshFrmCommunity.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: frshFrmCommunity_esModule, $$typeof: frshFrmCommunity_$$typeof } = frshFrmCommunity_proxy;
const frshFrmCommunity_default_ = frshFrmCommunity_proxy.default;

const frshFrmCommunity_e0 = frshFrmCommunity_proxy["FreshFromCommunity"];

;// CONCATENATED MODULE: ./components/landingPgComponents/ExploreNigerianRecipies.jsx

const ExploreNigerianRecipies_proxy = (0,module_proxy.createProxy)(String.raw`C:\Users\Ibinabo\Documents\GitHub\mkp-frontend\mkp\components\landingPgComponents\ExploreNigerianRecipies.jsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule: ExploreNigerianRecipies_esModule, $$typeof: ExploreNigerianRecipies_$$typeof } = ExploreNigerianRecipies_proxy;
const ExploreNigerianRecipies_default_ = ExploreNigerianRecipies_proxy.default;

const ExploreNigerianRecipies_e0 = ExploreNigerianRecipies_proxy["ExploreNigerianRecipies"];

;// CONCATENATED MODULE: ./components/footer.jsx

const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "mt-12 bg-gray py-16 text-left  font-poppins",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: " container mx-auto flex flex-wrap justify-between",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "text-sm list-none",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-lg font-semibold mb-3",
                                    children: "Recipes"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Quick and Easy"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "In the Kitchen"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Holiday and Seasons"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "text-sm list-none",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-lg font-semibold mb-3",
                                    children: "Resources"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "About Us"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Terms of Service"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "How it works"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Privacy Policy"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Contact Us"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "w-full md:w-1/4",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                            className: "text-sm list-none",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    className: "text-lg font-semibold mb-3",
                                    children: "Other"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Careers"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Webinars & events"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Our partners"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: "Cookies policy"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        className: "w-full md:w-1/4",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                className: "text-lg font-semibold mb-3",
                                children: "Ready to have fun in the kitchen?"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                children: "Sign Up for weekly Newletter"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: "flex items-center mt-4 w-full",
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        placeholder: "Enter your email",
                                        className: "bg-gray border-2 border-pink-300 p-4  w-full"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("button", {
                                        className: "bg-pink-200 text-brown w-full px-0.5 pt-4 border-none ml-2 pb-4 font-bold",
                                        children: "Sign Up"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "text-center text-xs mt-8",
                children: "\xa9 2023 Mykitchenpower All Rights Reserved. | Terms of Service"
            })
        ]
    });
};

;// CONCATENATED MODULE: ./app/page.js








const Home = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(e0, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(hero, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(searchBar_e0, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(latestRecipies_e0, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(frshFrmCommunity_e0, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(ExploreNigerianRecipies_e0, {})
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("section", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
            })
        ]
    });
};
/* harmony default export */ const page = (Home);


/***/ }),

/***/ 4666:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/heroImg.5488a0fa.png","height":778,"width":1440,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAAECAMAAACEE47CAAAAUVBMVEVyQRhVWDRhUDYqVAd3Sjh/cmBqXi5+XjdRHg1UbkqEhouvsLRWQB+YlpnDrZ6WkIxcPS7HhCGxmnllKSSTYUeSRg6NhIGtspYyEQeIendcQxk+woEjAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAK0lEQVR4nAXBhQEAIAwDsKLD3f8/lASMPyCQhrBNHjMU7K6zm+uwMhUZffoXjAF8fxCZhgAAAABJRU5ErkJggg==","blurWidth":8,"blurHeight":4});

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [333,598,707], () => (__webpack_exec__(9528)));
module.exports = __webpack_exports__;

})();